/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

/**
 *
 * @author Najib
 */


public class Voli extends AbstractClass{
    private int harga,total,lama;
    public Voli(int lama,int harga){
        this.harga = harga;
        this.lama = lama;
    }
    public int Total(){
        this.total = harga*lama;
        return total;
    }
}
